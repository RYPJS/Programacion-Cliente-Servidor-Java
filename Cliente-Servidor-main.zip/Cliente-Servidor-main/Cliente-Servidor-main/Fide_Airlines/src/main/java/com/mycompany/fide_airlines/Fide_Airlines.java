/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.fide_airlines;

import GUI.InicioSesion;

/**
 *
 * @author Aaron
 */
public class Fide_Airlines {

    public static void main(String[] args) {
        InicioSesion InicioSesion_p = new InicioSesion();
        InicioSesion_p.setVisible(true);
    }
}
